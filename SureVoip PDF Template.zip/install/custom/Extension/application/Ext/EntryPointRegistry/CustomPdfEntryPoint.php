<?php
$entry_point_registry['customGeneratePdf'] = array(
    'file' => 'custom/modules/AOS_PDF_Templates/customGeneratePdf.php',
    'auth' => false
);
