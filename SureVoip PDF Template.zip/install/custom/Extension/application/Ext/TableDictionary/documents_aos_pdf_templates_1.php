<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/documents_aos_pdf_templates_1MetaData.php');

?>