<?php
// created: 2017-10-31 13:24:03
$dictionary["Document"]["fields"]["documents_aos_pdf_templates_1"] = array (
  'name' => 'documents_aos_pdf_templates_1',
  'type' => 'link',
  'relationship' => 'documents_aos_pdf_templates_1',
  'source' => 'non-db',
  'module' => 'AOS_PDF_Templates',
  'bean_name' => 'AOS_PDF_Templates',
  'side' => 'right',
  'vname' => 'LBL_DOCUMENTS_AOS_PDF_TEMPLATES_1_FROM_AOS_PDF_TEMPLATES_TITLE',
);
