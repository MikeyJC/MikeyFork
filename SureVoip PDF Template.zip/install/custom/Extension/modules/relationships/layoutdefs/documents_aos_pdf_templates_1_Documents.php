<?php
 // created: 2017-10-31 13:24:03
$layout_defs["Documents"]["subpanel_setup"]['documents_aos_pdf_templates_1'] = array (
  'order' => 100,
  'module' => 'AOS_PDF_Templates',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_DOCUMENTS_AOS_PDF_TEMPLATES_1_FROM_AOS_PDF_TEMPLATES_TITLE',
  'get_subpanel_data' => 'documents_aos_pdf_templates_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
