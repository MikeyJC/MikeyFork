<?php
$mod_strings['LBL_PAGE_NUMBER'] = 'Insert into Page Number';
