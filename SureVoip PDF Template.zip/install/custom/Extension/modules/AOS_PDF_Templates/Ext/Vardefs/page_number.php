<?php
$dictionary['AOS_PDF_Templates']['fields']['page_number'] = array(
    'name' => 'page_number',
    'vname' => 'LBL_PAGE_NUMBER',
    'type' => 'int',
    'len' => 4,
    'reportable' => false,
    'source' => 'db',
    'studio' => 'visible',
);