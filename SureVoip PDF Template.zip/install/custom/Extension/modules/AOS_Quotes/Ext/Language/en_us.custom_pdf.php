<?php
$mod_strings['LBL_INSERT_INTO_PDF'] = 'Insert into PDF';