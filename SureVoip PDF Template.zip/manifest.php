<?php
$manifest =array (
  'acceptable_sugar_versions' => 
  array (
  ),
  'author' => 'SalesAgility',
  'description' => 'Adds Insert Into PDF functionality to Quotes and Invoices modules.',
  'icon' => '',
  'is_uninstallable' => 'true',
  'name' => 'SureVoip PDF Template',
  'published_date' => '2017-11-24 10:32:52',
  'type' => 'module',
  'version' => '1511519572',
);
$installdefs =array (
  'id' => 'sugar2017_11_24_103252',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_Invoices/Ext/Language/en_us.custom_pdf.php',
      'to' => 'custom/Extension/modules/AOS_Invoices/Ext/Language/en_us.custom_pdf.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/relationships/language/Documents.php',
      'to' => 'custom/Extension/modules/relationships/language/Documents.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/relationships/language/AOS_PDF_Templates.php',
      'to' => 'custom/Extension/modules/relationships/language/AOS_PDF_Templates.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/relationships/vardefs/documents_aos_pdf_templates_1_Documents.php',
      'to' => 'custom/Extension/modules/relationships/vardefs/documents_aos_pdf_templates_1_Documents.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/relationships/vardefs/documents_aos_pdf_templates_1_AOS_PDF_Templates.php',
      'to' => 'custom/Extension/modules/relationships/vardefs/documents_aos_pdf_templates_1_AOS_PDF_Templates.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/relationships/relationships/documents_aos_pdf_templates_1MetaData.php',
      'to' => 'custom/Extension/modules/relationships/relationships/documents_aos_pdf_templates_1MetaData.php',
    ),
    6 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/relationships/layoutdefs/documents_aos_pdf_templates_1_Documents.php',
      'to' => 'custom/Extension/modules/relationships/layoutdefs/documents_aos_pdf_templates_1_Documents.php',
    ),
    7 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_PDF_Templates/Ext/Language/en_us.customdocuments_aos_pdf_templates_1.php',
      'to' => 'custom/Extension/modules/AOS_PDF_Templates/Ext/Language/en_us.customdocuments_aos_pdf_templates_1.php',
    ),
    8 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_PDF_Templates/Ext/Language/en_us.page_number.php',
      'to' => 'custom/Extension/modules/AOS_PDF_Templates/Ext/Language/en_us.page_number.php',
    ),
    9 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_PDF_Templates/Ext/Vardefs/page_number.php',
      'to' => 'custom/Extension/modules/AOS_PDF_Templates/Ext/Vardefs/page_number.php',
    ),
    10 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_PDF_Templates/Ext/Vardefs/documents_aos_pdf_templates_1_AOS_PDF_Templates.php',
      'to' => 'custom/Extension/modules/AOS_PDF_Templates/Ext/Vardefs/documents_aos_pdf_templates_1_AOS_PDF_Templates.php',
    ),
    11 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_Quotes/Ext/Language/en_us.custom_pdf.php',
      'to' => 'custom/Extension/modules/AOS_Quotes/Ext/Language/en_us.custom_pdf.php',
    ),
    12 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Documents/Ext/Language/en_us.customdocuments_aos_pdf_templates_1.php',
      'to' => 'custom/Extension/modules/Documents/Ext/Language/en_us.customdocuments_aos_pdf_templates_1.php',
    ),
    13 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Documents/Ext/Vardefs/documents_aos_pdf_templates_1_Documents.php',
      'to' => 'custom/Extension/modules/Documents/Ext/Vardefs/documents_aos_pdf_templates_1_Documents.php',
    ),
    14 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Documents/Ext/Layoutdefs/documents_aos_pdf_templates_1_Documents.php',
      'to' => 'custom/Extension/modules/Documents/Ext/Layoutdefs/documents_aos_pdf_templates_1_Documents.php',
    ),
    15 => 
    array (
      'from' => '<basepath>/install/custom/Extension/application/Ext/TableDictionary/documents_aos_pdf_templates_1.php',
      'to' => 'custom/Extension/application/Ext/TableDictionary/documents_aos_pdf_templates_1.php',
    ),
    16 => 
    array (
      'from' => '<basepath>/install/custom/Extension/application/Ext/EntryPointRegistry/CustomPdfEntryPoint.php',
      'to' => 'custom/Extension/application/Ext/EntryPointRegistry/CustomPdfEntryPoint.php',
    ),
    17 => 
    array (
      'from' => '<basepath>/install/custom/metadata/documents_aos_pdf_templates_1MetaData.php',
      'to' => 'custom/metadata/documents_aos_pdf_templates_1MetaData.php',
    ),
    18 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Invoices/metadata/detailviewdefs.php',
      'to' => 'custom/modules/AOS_Invoices/metadata/detailviewdefs.php',
    ),
    19 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Invoices/templates/showPopupWithTemplates.tpl',
      'to' => 'custom/modules/AOS_Invoices/templates/showPopupWithTemplates.tpl',
    ),
    20 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Invoices/views/view.detail.php',
      'to' => 'custom/modules/AOS_Invoices/views/view.detail.php',
    ),
    21 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_PDF_Templates/metadata/detailviewdefs.php',
      'to' => 'custom/modules/AOS_PDF_Templates/metadata/detailviewdefs.php',
    ),
    22 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_PDF_Templates/metadata/editviewdefs.php',
      'to' => 'custom/modules/AOS_PDF_Templates/metadata/editviewdefs.php',
    ),
    23 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_PDF_Templates/customGeneratePdf.php',
      'to' => 'custom/modules/AOS_PDF_Templates/customGeneratePdf.php',
    ),
    24 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Quotes/metadata/detailviewdefs.php',
      'to' => 'custom/modules/AOS_Quotes/metadata/detailviewdefs.php',
    ),
    25 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Quotes/templates/showPopupWithTemplates.tpl',
      'to' => 'custom/modules/AOS_Quotes/templates/showPopupWithTemplates.tpl',
    ),
    26 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Quotes/views/view.detail.php',
      'to' => 'custom/modules/AOS_Quotes/views/view.detail.php',
    ),
  ),
  'beans' => 
  array (
  ),
  'logic_hooks' => 
  array (
  ),
);
