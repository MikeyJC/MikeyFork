<?php
$manifest =array (
  'acceptable_sugar_versions' => 
  array (
  ),
  'author' => 'SalesAgility',
  'description' => '',
  'icon' => '',
  'is_uninstallable' => 'true',
  'name' => 'Kashflow_SuiteCRM_Plugin',
  'published_date' => '2017-10-18 12:48:40',
  'type' => 'module',
  'version' => '1508327320',
);
$installdefs =array (
  'id' => 'sugar2017_10_18_124840',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_Products/Ext/Language/en_us.kashflow_product_fields.php',
      'to' => 'custom/Extension/modules/AOS_Products/Ext/Language/en_us.kashflow_product_fields.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_Products/Ext/Vardefs/kashflow_product_fields.php',
      'to' => 'custom/Extension/modules/AOS_Products/Ext/Vardefs/kashflow_product_fields.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_Products/Ext/LogicHooks/Kashflow_Hooks.php',
      'to' => 'custom/Extension/modules/AOS_Products/Ext/LogicHooks/Kashflow_Hooks.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Contacts/Ext/Language/en_us.kashflow_contacts_fields.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Language/en_us.kashflow_contacts_fields.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Contacts/Ext/Vardefs/kashflow_contacts_fields.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Vardefs/kashflow_contacts_fields.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Contacts/Ext/LogicHooks/Kashflow_Hooks.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/LogicHooks/Kashflow_Hooks.php',
    ),
    6 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_Invoices/Ext/Language/en_us.kashflow_aos_invoices_fields.php',
      'to' => 'custom/Extension/modules/AOS_Invoices/Ext/Language/en_us.kashflow_aos_invoices_fields.php',
    ),
    7 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_Invoices/Ext/Vardefs/kashflow_aos_invoices_fields.php',
      'to' => 'custom/Extension/modules/AOS_Invoices/Ext/Vardefs/kashflow_aos_invoices_fields.php',
    ),
    8 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_Invoices/Ext/LogicHooks/Kashflow_Hooks.php',
      'to' => 'custom/Extension/modules/AOS_Invoices/Ext/LogicHooks/Kashflow_Hooks.php',
    ),
    9 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Administration/Ext/Language/en_us.Kashflow.php',
      'to' => 'custom/Extension/modules/Administration/Ext/Language/en_us.Kashflow.php',
    ),
    10 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Administration/Ext/Administration/Kashflow.php',
      'to' => 'custom/Extension/modules/Administration/Ext/Administration/Kashflow.php',
    ),
    11 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Schedulers/Ext/ScheduledTasks/KashflowTasks.php',
      'to' => 'custom/Extension/modules/Schedulers/Ext/ScheduledTasks/KashflowTasks.php',
    ),
    12 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Accounts/Ext/Vardefs/kashflow_accounts_fields.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/Vardefs/kashflow_accounts_fields.php',
    ),
    13 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/Accounts/Ext/LogicHooks/Kashflow_Hooks.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/LogicHooks/Kashflow_Hooks.php',
    ),
    14 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_Products_Quotes/Ext/Vardefs/kashflow_line_item_fields.php',
      'to' => 'custom/Extension/modules/AOS_Products_Quotes/Ext/Vardefs/kashflow_line_item_fields.php',
    ),
    15 => 
    array (
      'from' => '<basepath>/install/custom/Extension/modules/AOS_Products_Quotes/Ext/LogicHooks/Kashflow_Hooks.php',
      'to' => 'custom/Extension/modules/AOS_Products_Quotes/Ext/LogicHooks/Kashflow_Hooks.php',
    ),
    16 => 
    array (
      'from' => '<basepath>/install/custom/Extension/application/Ext/Language/en_us.Kashflow.php',
      'to' => 'custom/Extension/application/Ext/Language/en_us.Kashflow.php',
    ),
    17 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Products/Kashflow_Products.php',
      'to' => 'custom/modules/AOS_Products/Kashflow_Products.php',
    ),
    18 => 
    array (
      'from' => '<basepath>/install/custom/modules/Administration/KashflowGetNominalCodes.php',
      'to' => 'custom/modules/Administration/KashflowGetNominalCodes.php',
    ),
    19 => 
    array (
      'from' => '<basepath>/install/custom/modules/Administration/KashflowConfiguration.php',
      'to' => 'custom/modules/Administration/KashflowConfiguration.php',
    ),
    20 => 
    array (
      'from' => '<basepath>/install/custom/modules/Administration/KashflowTestConnection.js',
      'to' => 'custom/modules/Administration/KashflowTestConnection.js',
    ),
    21 => 
    array (
      'from' => '<basepath>/install/custom/modules/Administration/KashflowTestConnection.php',
      'to' => 'custom/modules/Administration/KashflowTestConnection.php',
    ),
    22 => 
    array (
      'from' => '<basepath>/install/custom/modules/Administration/KashflowConfiguration.tpl',
      'to' => 'custom/modules/Administration/KashflowConfiguration.tpl',
    ),
    23 => 
    array (
      'from' => '<basepath>/install/custom/modules/Configurator/CustomConfigurator.php',
      'to' => 'custom/modules/Configurator/CustomConfigurator.php',
    ),
    24 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Products_Quotes/Kashflow_Line_Items.php',
      'to' => 'custom/modules/AOS_Products_Quotes/Kashflow_Line_Items.php',
    ),
    25 => 
    array (
      'from' => '<basepath>/install/custom/include/Kashflow/Kashflow_Customer_Hooks.php',
      'to' => 'custom/include/Kashflow/Kashflow_Customer_Hooks.php',
    ),
    26 => 
    array (
      'from' => '<basepath>/install/custom/include/Kashflow/Kashflow.php',
      'to' => 'custom/include/Kashflow/Kashflow.php',
    ),
    27 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Invoices/Kashflow_Invoices.php',
      'to' => 'custom/modules/AOS_Invoices/Kashflow_Invoices.php',
    ),
    28 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Invoices/metadata/detailviewdefs.php',
      'to' => 'custom/modules/AOS_Invoices/metadata/detailviewdefs.php',
    ),
    29 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Products/metadata/detailviewdefs.php',
      'to' => 'custom/modules/AOS_Products/metadata/detailviewdefs.php',
    ),
    30 => 
    array (
      'from' => '<basepath>/install/custom/modules/AOS_Products/metadata/editviewdefs.php',
      'to' => 'custom/modules/AOS_Products/metadata/editviewdefs.php',
    ),
    31 => 
    array (
      'from' => '<basepath>/install/custom/modules/Contacts/metadata/editviewdefs.php',
      'to' => 'custom/modules/Contacts/metadata/editviewdefs.php',
    ),
    32 => 
    array (
      'from' => '<basepath>/install/custom/modules/Contacts/metadata/detailviewdefs.php',
      'to' => 'custom/modules/Contacts/metadata/detailviewdefs.php',
    ),
  ),
  'beans' => 
  array (
  ),
  'logic_hooks' => 
  array (
  ),
);
