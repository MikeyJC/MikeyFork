<?php

$mod_strings['LBL_AMOUNT_PAID'] = 'Amount Paid';
$mod_strings['LBL_KASHFLOW_ID'] = 'Kashflow ID';
$mod_strings['LBL_FAILED_TO_SEND'] = 'Failed to send product details to Kashflow. Please check Kashflow details in admin panel.';