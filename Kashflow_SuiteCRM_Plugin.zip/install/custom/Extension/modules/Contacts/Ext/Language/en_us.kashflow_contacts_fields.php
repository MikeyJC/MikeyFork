<?php

$mod_strings['LBL_BILLING_CONTACT'] = 'Billing Contact';
$mod_strings['LBL_FAILED_TO_SEND'] = 'Failed to send product details to Kashflow. Please check Kashflow details in admin panel.';
$mod_strings['LBL_KASHFLOW_BILLING_CONTACT_EXISTS'] = 'Parent Account\'s Billing Contact has been updated';