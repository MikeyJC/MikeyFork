<?php

$mod_strings['LBL_KASHFLOW_ID'] = 'Kashflow ID';
$mod_strings['LBL_NOMINAL_CODE'] = 'Nominal Code';
$mod_strings['LBL_VAT_RATE'] = 'VATRate';
$mod_strings['LBL_MANAGED'] = 'Managed';
$mod_strings['LBL_QTY_IN_STOCK'] = 'QtyInStock';
$mod_strings['LBL_STOCK_WARN_QTY'] = 'StockWarnQty';
$mod_strings['LBL_AUTOFILL'] = 'Autofill';
$mod_strings['LBL_FAILED_TO_SEND'] = 'Failed to send product details to Kashflow. Please check Kashflow details in admin panel.';